package com.ejemplo.tarea;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edit1;
    private EditText edit2;
    private EditText edit3;
    private TextView tv1;
    // adicionamos
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit3 = (EditText) findViewById(R.id.txt_num);
        edit1 = (EditText) findViewById(R.id.txt_num1);
        edit2 = (EditText) findViewById(R.id.txt_num2);
        tv1 = (TextView) findViewById(R.id.txt_view1);
        }
            /*Metodo para calcular*/
        public void Calcular(View view) {
        String valor1 = edit1.getText().toString();
        String valor2 = edit2.getText().toString();
        String valor3 = edit2.getText().toString();
        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);
        int num3 = Integer.parseInt(valor3);
         int suma = num1 + num2 + num3;
         int dividir = suma/3;
         if(dividir >= 10 ) {

                tv1.setText("LA NOTA SOBREPASA LOS 10 PUNTOS");
         }else{
             if (dividir >= 6) {
                 String resulPr = String.valueOf(dividir);
                 tv1.setText("APROBO con un promedio  " + resulPr);
             } else {
                 tv1.setText("REPROBO CON" + dividir);
             }

         }   }
        }